#include <stdio.h>

int main(){

	//int *a;
	//int b;
	printf("size of pointer is  %d bytes\nsize of int is %d bytes\n",sizeof(int*),sizeof(int));
	return 0;
}
