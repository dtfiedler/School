#include <unistd.h>
#include <stdio.h>
int main(){
	int page_size = getpagesize();
	printf("the page size of the current machine is %d\n",page_size);
}
