#include <assert.h>
#include <stdlib.h>
#include "mem.h"
#include <stdio.h>
int main(){
	Mem_Init(1);
	Mem_Dump();
	return 0;
}

