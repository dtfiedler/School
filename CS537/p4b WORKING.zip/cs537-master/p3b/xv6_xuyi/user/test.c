#include "types.h"
#include "stat.h"
#include "user.h"

int main (int argc, char* argv[])
{
        int *x = 0;
        printf(1, "*x is = %x\n", *x);
        exit();
}
