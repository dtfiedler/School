#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[])
{
	printf("the number of argc is: %d", argc);
	return 0;
}
