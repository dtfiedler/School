CS564-Project 3 Log

10/8/2012
JH: Files copied from CS564-1 directory.
DM: Pseudo code for the four functions.

10/10/2012
JH: Posted to GitHub. Implemented BufMgr::allocBuf() and BufMgr::readPage().