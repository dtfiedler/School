var searchData=
[
  ['record_5fid_5f',['record_id_',['../classbadgerdb_1_1_invalid_record_exception.html#af1a2e1ad376303aa5411b7d168634586',1,'badgerdb::InvalidRecordException']]],
  ['refbit',['refbit',['../classbadgerdb_1_1_bad_buffer_exception.html#af871746d373d9a16e2203a783e06d00e',1,'badgerdb::BadBufferException']]]
];
