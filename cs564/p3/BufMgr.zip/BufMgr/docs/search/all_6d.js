var searchData=
[
  ['message',['message',['../classbadgerdb_1_1_badger_db_exception.html#a892c874d2517909698ae95d04c3553b0',1,'badgerdb::BadgerDbException']]],
  ['message_5f',['message_',['../classbadgerdb_1_1_badger_db_exception.html#a4510b66828c819004489218abeb1cf32',1,'badgerdb::BadgerDbException']]]
];
