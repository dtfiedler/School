var searchData=
[
  ['data_5fsize',['DATA_SIZE',['../classbadgerdb_1_1_page.html#a74057ec71412352ef0aa5913bbebed25',1,'badgerdb::Page']]],
  ['deletepage',['deletePage',['../classbadgerdb_1_1_file.html#a829a68ccfbeb0c9f66f3a2db7e0b99fe',1,'badgerdb::File']]],
  ['deleterecord',['deleteRecord',['../classbadgerdb_1_1_page.html#a1bc17754b4ed548f8520a6274b3a4202',1,'badgerdb::Page']]],
  ['dirty',['dirty',['../classbadgerdb_1_1_bad_buffer_exception.html#a798550763485a56b34ee254b238f3336',1,'badgerdb::BadBufferException']]],
  ['diskreads',['diskreads',['../structbadgerdb_1_1_buf_stats.html#a60cde025ce745b6bc41a0ba27daf04e0',1,'badgerdb::BufStats']]],
  ['diskwrites',['diskwrites',['../structbadgerdb_1_1_buf_stats.html#a4bd2081fdaddaa309b401575eeb6a86e',1,'badgerdb::BufStats']]],
  ['disposepage',['disposePage',['../classbadgerdb_1_1_buf_mgr.html#a870a80a0f0abcf3b640b913b46b64486',1,'badgerdb::BufMgr']]]
];
