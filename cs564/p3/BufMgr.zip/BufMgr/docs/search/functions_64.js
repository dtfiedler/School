var searchData=
[
  ['deletepage',['deletePage',['../classbadgerdb_1_1_file.html#a829a68ccfbeb0c9f66f3a2db7e0b99fe',1,'badgerdb::File']]],
  ['deleterecord',['deleteRecord',['../classbadgerdb_1_1_page.html#a1bc17754b4ed548f8520a6274b3a4202',1,'badgerdb::Page']]],
  ['disposepage',['disposePage',['../classbadgerdb_1_1_buf_mgr.html#a870a80a0f0abcf3b640b913b46b64486',1,'badgerdb::BufMgr']]]
];
